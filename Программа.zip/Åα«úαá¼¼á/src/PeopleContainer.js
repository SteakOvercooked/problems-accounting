import React from 'react'

class PeopleContainer extends React.Component {
    constructor(props) {
        super(props)
    }

    render() {
        return (
            <div id="people_container">
                
            </div>
        )
    }
}

export { PeopleContainer }